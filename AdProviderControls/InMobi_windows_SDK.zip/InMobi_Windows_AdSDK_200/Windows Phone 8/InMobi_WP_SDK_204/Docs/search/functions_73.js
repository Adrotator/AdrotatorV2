var searchData=
[
  ['setadbackgroundgradientcolor',['SetAdBackgroundGradientColor',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a77aa306bd9e0cef8e20a7142c13dba63',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['showad',['ShowAd',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#a4210e4788a98cf2fc53f81f510a1d213',1,'InMobi::WP::AdSDK::IMAdInterstitial']]],
  ['stoploading',['StopLoading',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#af1597d7752e9c47a3c82584dce53d937',1,'InMobi.WP.AdSDK.IMAdView.StopLoading()'],['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#afed90036e2b5c9fddcfd0cb4c5f10895',1,'InMobi.WP.AdSDK.IMAdInterstitial.StopLoading()']]]
];
