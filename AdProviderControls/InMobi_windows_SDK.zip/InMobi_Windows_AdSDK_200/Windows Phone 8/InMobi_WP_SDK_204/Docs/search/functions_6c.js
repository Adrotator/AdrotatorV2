var searchData=
[
  ['loadnewad',['LoadNewAd',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a0b0d035736c8157ee4a2af3221856ff6',1,'InMobi.WP.AdSDK.IMAdView.LoadNewAd()'],['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a3be5a2548580bed13be9e04888144691',1,'InMobi.WP.AdSDK.IMAdView.LoadNewAd(IMAdRequest imAdRequest)'],['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#a36ead53f206d6c9cf18a8055499b8319',1,'InMobi.WP.AdSDK.IMAdInterstitial.LoadNewAd(IMAdRequest IMAdRequest)'],['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#a1340fd63c66f873a14f2586774aec630',1,'InMobi.WP.AdSDK.IMAdInterstitial.LoadNewAd()']]]
];
