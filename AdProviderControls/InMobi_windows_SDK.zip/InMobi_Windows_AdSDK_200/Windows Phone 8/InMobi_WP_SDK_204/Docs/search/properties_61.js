var searchData=
[
  ['adbackgroundcolor',['AdBackgroundColor',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a10b9f19373ac0c0c3b7f4f5fd313450c',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['adsize',['AdSize',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a548af0ea82f4768ec23d4126b35924ea',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['adtextcolor',['AdTextColor',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a967f6b685a11b220f7d25fdba8dbc870',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['age',['Age',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_request.html#aa3dfed672f3830f0752ff4d372568777',1,'InMobi::WP::AdSDK::IMAdRequest']]],
  ['animationtype',['AnimationType',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a808deed6cf995f67ab6625e068a0582f',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['appid',['AppId',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a3b8979914a512e424f5b3836181a084f',1,'InMobi.WP.AdSDK.IMAdView.AppId()'],['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#ad036a5f6e87853cb051a357860e02f26',1,'InMobi.WP.AdSDK.IMAdInterstitial.AppId()']]],
  ['areacode',['AreaCode',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_request.html#ac25dab5c5995713e62fd709e55a6a81f',1,'InMobi::WP::AdSDK::IMAdRequest']]]
];
