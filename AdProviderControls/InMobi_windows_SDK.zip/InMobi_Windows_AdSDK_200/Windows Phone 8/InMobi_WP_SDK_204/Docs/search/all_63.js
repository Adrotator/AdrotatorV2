var searchData=
[
  ['city',['City',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_user_location.html#a9755d00dd9920aeee83a7cda6efdd224',1,'InMobi::WP::AdSDK::UserLocation']]],
  ['country',['Country',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_user_location.html#a52160d405f16ddd6a717a1988694d06f',1,'InMobi::WP::AdSDK::UserLocation']]]
];
