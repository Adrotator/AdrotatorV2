var searchData=
[
  ['refreshinterval',['RefreshInterval',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a9d69028cee11c03df183cd32390b30e8',1,'InMobi::WP::AdSDK::IMAdView']]],
  ['reftag',['RefTag',['../class_in_mobi_1_1_w_p_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a4cea2799e73209c9d90c7cb3c0d3b127',1,'InMobi::WP::AdSDK::IMAdView']]]
];
