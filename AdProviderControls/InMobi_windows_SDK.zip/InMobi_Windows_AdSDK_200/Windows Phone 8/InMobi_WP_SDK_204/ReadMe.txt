========================================
INMobi Ad SDK [Windows Phone 8]
========================================

The SDK provides:
- IMAdview. Used to display the banner ads for available ad size

Minimum Requirements:
- InMobi Account 
- Visual Studio 2012 Professional Edition 
- Windows Phone 8 SDK 

How to start?
The sample folder contains a Visual Studio 2012 Solution which describes the use of Ad SDK.
Set YOUR_APP_ID and rebuild. You should be good to go.

For further help:
http://developer.inmobi.com/



