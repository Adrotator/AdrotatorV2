========================================
INMobi Ad SDK [Windows Phone 7]
========================================

The SDK provides:
- IMAdview. Used to display the text and banner Ads for available ad slots

Minimum Requirements:
- InMobi Account 
- Visual Studio 2010 or Visual Studio 2012
- Windows Phone 7 SDK 

How to start?
The samples folder contains a Visual Studio 2010 Solution which describes the use of Ad SDK.



