var searchData=
[
  ['loadnewad',['LoadNewAd',['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#af968f5af084b0dc1057c42b816edee44',1,'InMobi::WpSdk::IMAdView.LoadNewAd(IMAdRequest adRequest)'],['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#a548e10275e44ae7d00ad76bea2f60ae6',1,'InMobi::WpSdk::IMAdView.LoadNewAd()']]]
];
