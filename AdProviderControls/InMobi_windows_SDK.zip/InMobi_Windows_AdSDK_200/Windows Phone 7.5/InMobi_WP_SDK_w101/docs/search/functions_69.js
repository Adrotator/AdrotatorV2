var searchData=
[
  ['imadview',['IMAdView',['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#a8c8e9a71f8bd1d7ac8e392fc31c4731b',1,'InMobi::WpSdk::IMAdView.IMAdView()'],['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#af9af718dd31b250116cbd211834749d5',1,'InMobi::WpSdk::IMAdView.IMAdView(string AppId, int AdSize)']]]
];
