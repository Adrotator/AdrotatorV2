var searchData=
[
  ['setadbackgroundgradientcolor',['SetAdBackgroundGradientColor',['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#a5481a180e2c6ba5b3d20956d64da2f06',1,'InMobi::WpSdk::IMAdView']]]
];
