var searchData=
[
  ['dateofbirth',['DateOfBirth',['../class_in_mobi_1_1_wp_sdk_1_1_user_info.html#ad8a880ae949dafbd69fbb871d61efc74',1,'InMobi::WpSdk::UserInfo']]],
  ['displaytext',['DisplayText',['../class_in_mobi_1_1_wp_sdk_1_1_i_m_ad_view.html#a5c8a9db338ccdd5d04bf4154fc91c6ae',1,'InMobi::WpSdk::IMAdView']]]
];
