var searchData=
[
  ['gender',['Gender',['../class_in_mobi_1_1_wp_sdk_1_1_user_info.html#a6dc0689caf39671de77406bc818d9013',1,'InMobi::WpSdk::UserInfo']]],
  ['gendertype',['GenderType',['../namespace_in_mobi_1_1_wp_sdk.html#a0fe66958098165bf59e8bac4e522c96e',1,'InMobi::WpSdk']]]
];
