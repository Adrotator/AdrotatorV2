var searchData=
[
  ['city',['City',['../class_in_mobi_1_1_wp_sdk_1_1_user_location.html#a650bfc85a9e32abd7defbc189cc8545a',1,'InMobi::WpSdk::UserLocation']]],
  ['country',['Country',['../class_in_mobi_1_1_wp_sdk_1_1_user_location.html#ae0a0b400c712dabecf290bd8f918a598',1,'InMobi::WpSdk::UserLocation']]]
];
