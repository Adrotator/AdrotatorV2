var searchData=
[
  ['refreshinterval',['RefreshInterval',['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a6843244fc5f9ef2a4961a74d1fef820b',1,'InMobi::W8::AdSDK::IMAdView']]],
  ['reftag',['RefTag',['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_view.html#aa062b42cda1ec89a5153c06c5aba3c0a',1,'InMobi::W8::AdSDK::IMAdView']]]
];
