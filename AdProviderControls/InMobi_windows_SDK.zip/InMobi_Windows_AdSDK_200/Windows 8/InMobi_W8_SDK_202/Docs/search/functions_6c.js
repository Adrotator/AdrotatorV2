var searchData=
[
  ['loadnewad',['LoadNewAd',['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_view.html#ae1b7d9fc2658583d9a04d2c78543fc9c',1,'InMobi.W8.AdSDK.IMAdView.LoadNewAd()'],['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_view.html#a106173d97c75de27346f55bd9995256c',1,'InMobi.W8.AdSDK.IMAdView.LoadNewAd(IMAdRequest imAdRequest)'],['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#a07043ed4b7722bb15d066c5a1719f616',1,'InMobi.W8.AdSDK.IMAdInterstitial.LoadNewAd()'],['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_i_m_ad_interstitial.html#a0a503ceec4e2767cb84e1181a5cabba3',1,'InMobi.W8.AdSDK.IMAdInterstitial.LoadNewAd(IMAdRequest IMAdRequest)']]]
];
