var searchData=
[
  ['city',['City',['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_user_location.html#a97cebd1ccd31361101ab26ce5a842ac2',1,'InMobi::W8::AdSDK::UserLocation']]],
  ['country',['Country',['../class_in_mobi_1_1_w8_1_1_ad_s_d_k_1_1_user_location.html#a181e57bd934e40798003e9aea4dceca3',1,'InMobi::W8::AdSDK::UserLocation']]]
];
