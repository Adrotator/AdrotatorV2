========================================
INMobi Ad SDK [Windows Store Apps]
========================================

The SDK provides:
- IMAdview. Used to display the banner ads for available ad slots

Minimum Requirements:
- InMobi Developer Account 
- Visual Studio 2012 Professional Edition 


How to start?
The samples folder contains a Visual Studio 2012 Solution which describes the use of Ad SDK.

For furher help:
http://developer.inmobi.com/