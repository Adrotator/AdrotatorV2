﻿using UnityEngine;
using System.Collections;

public class MoveAdScript : MonoBehaviour 
{
    private int clickCount = 1;

    void OnGUI()
    {        
        GUI.skin.button.fontSize = 75;
        GUI.skin.button.fontStyle = FontStyle.Normal;
        GUI.skin.button.alignment = TextAnchor.UpperCenter;
        var buttonVerticalPosition = clickCount % 2 == 0 ? 0 : Screen.height - 125;

        if (GUI.Button(new Rect(Screen.width / 2 - 250, buttonVerticalPosition, 500, 125), "Move Ad"))
        {
            clickCount++;
            MoveAd(buttonVerticalPosition != 0);          
        }
    }

    void Awake()
    {
        var ads = GameObject.Find("AdRotatorManagement");
        if (ads != null)
        {
            var adMgt = ads.GetComponent<AdRotatorUnitySDK.Assets.Plugins.AdRotatorManagement>();
            adMgt.AdSettings.IsEnabled = true;
            adMgt.UpdateAd();
        }
        else
        {
            Debug.LogError("AdRotatorManagement game object cannot be found, check that AdRotator is configured properly in your initial scene.");
        }
    }

    private void MoveAd(bool isButtonTop)
    {
        var ads = GameObject.Find("AdRotatorManagement");
        if (ads != null)
        {
            var adMgt = ads.GetComponent<AdRotatorUnitySDK.Assets.Plugins.AdRotatorManagement>();            
            
            if (isButtonTop)
            {
                adMgt.AdSettings.Position = AdRotatorUnitySDK.Assets.Plugins.AdPosition.BottomCenter;
                adMgt.AdSettings.SlidingAdDirection = AdRotatorUnitySDK.Assets.Plugins.SlidingAdDirection.Bottom;
            }
            else
            {
                adMgt.AdSettings.Position = AdRotatorUnitySDK.Assets.Plugins.AdPosition.TopCenter;
                adMgt.AdSettings.SlidingAdDirection = AdRotatorUnitySDK.Assets.Plugins.SlidingAdDirection.Top;
            }

            adMgt.AdSettings.IsEnabled = true;
            adMgt.UpdateAd();
        }
        else
        {
            Debug.LogError("AdRotatorManagement game object cannot be found, check that AdRotator is configured properly in your initial scene.");
        }
    }
}