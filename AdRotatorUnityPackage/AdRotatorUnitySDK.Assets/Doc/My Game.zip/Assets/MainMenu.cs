﻿using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour 
{
    void OnGUI()
    {
        GUI.skin.button.fontSize = 75;
        GUI.skin.button.fontStyle = FontStyle.Normal;
        GUI.skin.button.alignment = TextAnchor.UpperCenter;

        if (GUI.Button(new Rect(Screen.width / 2 - 250, Screen.height / 2 - 150, 500, 125), "New Game"))
        {
            Application.LoadLevel("NewGame");
        }
        else if (GUI.Button(new Rect(Screen.width / 2 - 250, Screen.height / 2, 500, 125), "Load Game"))
        {
            
        }
    }
}
